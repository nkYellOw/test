﻿namespace scrape_getfpv_com
{
  public class ObjectCsv
  {
    public string Name { get; set; }
    public string Category_1 { get; set; }
    public string Category_2 { get; set; }
    public string Category_3 { get; set; }
    public string Image_1 { get; set; }
    public string Image_2 { get; set; }
    public string Image_3 { get; set; }
    public string Description { get; set; }
  }
}
