﻿namespace scrape_getfpv_com
{
  partial class Form1
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Загрузка категорий...");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.Button_StartScrape = new System.Windows.Forms.Button();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.checkBoxAll_ON = new System.Windows.Forms.CheckBox();
            this.checkBoxAll_OFF = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // treeView1
            // 
            this.treeView1.CheckBoxes = true;
            this.treeView1.Location = new System.Drawing.Point(11, 97);
            this.treeView1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.treeView1.Name = "treeView1";
            treeNode1.Name = "Node0";
            treeNode1.Text = "Загрузка категорий...";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1});
            this.treeView1.Size = new System.Drawing.Size(549, 675);
            this.treeView1.TabIndex = 0;
            this.treeView1.AfterCheck += new System.Windows.Forms.TreeViewEventHandler(this.TreeView1_AfterCheck);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBoxAll_OFF);
            this.groupBox1.Controls.Add(this.checkBoxAll_ON);
            this.groupBox1.Controls.Add(this.treeView1);
            this.groupBox1.Location = new System.Drawing.Point(22, 22);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.groupBox1.Size = new System.Drawing.Size(574, 786);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Категории";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 24;
            this.listBox1.Location = new System.Drawing.Point(607, 76);
            this.listBox1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(549, 652);
            this.listBox1.TabIndex = 7;
            // 
            // Button_StartScrape
            // 
            this.Button_StartScrape.Location = new System.Drawing.Point(607, 22);
            this.Button_StartScrape.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Button_StartScrape.Name = "Button_StartScrape";
            this.Button_StartScrape.Size = new System.Drawing.Size(552, 42);
            this.Button_StartScrape.TabIndex = 5;
            this.Button_StartScrape.Text = "Старт";
            this.Button_StartScrape.UseVisualStyleBackColor = true;
            this.Button_StartScrape.Click += new System.EventHandler(this.Button_StartScrape_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(607, 755);
            this.progressBar1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(552, 42);
            this.progressBar1.TabIndex = 6;
            // 
            // checkBoxAll_ON
            // 
            this.checkBoxAll_ON.AutoSize = true;
            this.checkBoxAll_ON.Location = new System.Drawing.Point(11, 31);
            this.checkBoxAll_ON.Name = "checkBoxAll_ON";
            this.checkBoxAll_ON.Size = new System.Drawing.Size(109, 29);
            this.checkBoxAll_ON.TabIndex = 1;
            this.checkBoxAll_ON.Text = "ALL ON";
            this.checkBoxAll_ON.UseVisualStyleBackColor = true;
            this.checkBoxAll_ON.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBoxAll_OFF
            // 
            this.checkBoxAll_OFF.AutoSize = true;
            this.checkBoxAll_OFF.Location = new System.Drawing.Point(138, 31);
            this.checkBoxAll_OFF.Name = "checkBoxAll_OFF";
            this.checkBoxAll_OFF.Size = new System.Drawing.Size(105, 29);
            this.checkBoxAll_OFF.TabIndex = 2;
            this.checkBoxAll_OFF.Text = "All OFF";
            this.checkBoxAll_OFF.UseVisualStyleBackColor = true;
            this.checkBoxAll_OFF.CheckedChanged += new System.EventHandler(this.checkBoxAll_OFF_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1188, 831);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.Button_StartScrape);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "Form1";
            this.Text = "Парсер getfpv.com - Scrape Studio";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.TreeView treeView1;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.ListBox listBox1;
    private System.Windows.Forms.Button Button_StartScrape;
    private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.CheckBox checkBoxAll_OFF;
        private System.Windows.Forms.CheckBox checkBoxAll_ON;
    }
}

